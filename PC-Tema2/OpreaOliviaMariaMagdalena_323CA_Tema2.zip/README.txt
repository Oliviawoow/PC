Copyright 2020 Oprea Olivia Maria-Magdalena 323CA <opreaolivia73@gmail.com>
In colaborare cu echipa de pc care a facut laburile din care am luat codul :)

------------------------------------SERVER-------------------------------------

Serverul asteapta orice conexiune si va impartii conexiunile in TCP si UDP si
va salva socketii conexiunii TCP. Clientii TCP se vor conecta cu un ID pe care
il trimit intr-un mesaj catre server. Acestia vor putea sa se aboneze/ sa se
dezaboneze de la un anumit topic. Serverul va primii de la clientii UDP un 
mesaj pe care il va traduce pentru un client TCP. La primirea comenzii exit
va inchide serverul si conexiunile active.

------------------------------------CLIENT-------------------------------------

Clientul se va conecta la server, va trimite ID-ul si va trimite comenzi de tipul
subscribe/ unsubscribe sau va astepta comanda exit. In cazul in care serverul 
inchide conexiunea, aceasta se va inchide. In momentul in care primeste un mesaj
de la o subscriptie acesta va afisa mesajul conform cerintei.
