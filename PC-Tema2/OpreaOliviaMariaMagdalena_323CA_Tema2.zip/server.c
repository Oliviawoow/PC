// Copyright 2020 Oprea Olivia Maria-Magdalena 323CA <opreaolivia73@gmail.com>
// In colaborare cu echipa de pc care a facut laburile din care am luat codul :)

#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <unistd.h>
#include <sys/types.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <netinet/ip.h>
#include <arpa/inet.h>
#include <stdbool.h>
#include <math.h>
#include "helpers.h"

void usage(char *file) {
	fprintf(stderr, "Usage: %s server_port\n", file);
	exit(0);
}

void close_all_clients(fd_set *fds, int max_fd) {
	for (int i = 1; i <= max_fd; ++i) {
        if (FD_ISSET(i, fds)) {
            close(i);
        }
    }
}

typedef struct {
	char* topic;
	int sf;
	char id;
	int socket;
} subscribers;

struct recv_msg_t {
    char topic_name[50];
    uint8_t type;
    char data[1501];
};

struct tcp_msg_t {
	uint16_t udp_port;
	char* ip;
	char topic_name[50];
	char type;
	char data[1501];
};

int main(int argc, char *argv[]) {
	
	int udp_sockfd, tcp_sockfd, newsockfd, portno;
	char buffer[BUFLEN];
	int n, i, ret;
	socklen_t clilen;
	subscribers list_subscribers[100];
	int curent_sub = 0;
	bool exit_msg = false;

	socklen_t udp_socklen, tcp_socklen;
    struct sockaddr_in udp_addr, tcp_addr, new_tcp;

	struct recv_msg_t* udp_msg;
	struct tcp_msg_t tcp_msg;
	char clients_id[10];

	fd_set read_fds;	// multimea de citire folosita in select()
	fd_set tmp_fds;		// multime folosita temporar
	int fdmax;			// valoare maxima fd din multimea read_fds

	if (argc < 2) {
		usage(argv[0]);
	}

	// se goleste multimea de descriptori de citire (read_fds) si multimea temporara (tmp_fds)
	FD_ZERO(&read_fds);
	FD_ZERO(&tmp_fds);

	udp_sockfd = socket(PF_INET, SOCK_DGRAM, 0);
	DIE(udp_sockfd < 0, "udp_socket");

	tcp_sockfd = socket(AF_INET, SOCK_STREAM, 0);
	DIE(tcp_sockfd < 0, "tcp_socket");

	portno = atoi(argv[1]);
	DIE(portno == 0, "atoi");

	udp_addr.sin_family = tcp_addr.sin_family = AF_INET;
    udp_addr.sin_port = tcp_addr.sin_port = htons(portno);
    udp_addr.sin_addr.s_addr = tcp_addr.sin_addr.s_addr = INADDR_ANY;


	ret = bind(udp_sockfd, (struct sockaddr *) &udp_addr, sizeof(struct sockaddr));
	DIE(ret < 0, "udp_bind");
	ret = bind(tcp_sockfd, (struct sockaddr *) &tcp_addr, sizeof(struct sockaddr));
	DIE(ret < 0, "tcp_bind");

	ret = listen(tcp_sockfd, MAX_CLIENTS);
	DIE(ret < 0, "listen");

	// se adauga noul file descriptor (socketul pe care se asculta conexiuni) in multimea read_fds
	FD_SET(0, &read_fds);
	FD_SET(udp_sockfd, &read_fds);
	FD_SET(tcp_sockfd, &read_fds);
	fdmax = tcp_sockfd;

	while (!exit_msg) {
		tmp_fds = read_fds; 
		memset(buffer, 0, BUFLEN);
		
		ret = select(fdmax + 1, &tmp_fds, NULL, NULL, NULL);
		DIE(ret < 0, "select");

		for (i = 0; i <= fdmax; i++) {
			if (FD_ISSET(i, &tmp_fds)) {
				if (!i) {
					fgets(buffer, BUFLEN - 1, stdin);
					if (strcmp(buffer, "exit\n") == 0) {
	                    exit_msg = true;
	                    break;
	            	} else {
	                	printf("Only `exit` is allowed \n");
	            	}
				} else if(i == udp_sockfd) {
					udp_socklen = sizeof(udp_addr);
					n = recvfrom(udp_sockfd, buffer, BUFLEN - 1, 0, (struct sockaddr*) (&udp_addr), &udp_socklen);
					DIE(n < 0, "udp_recv");
					tcp_msg.udp_port = ntohs(udp_addr.sin_port);

					strcpy(tcp_msg.ip, inet_ntoa(udp_addr.sin_addr));
					udp_msg = (struct recv_msg_t*) buffer;
					strncpy(tcp_msg.topic_name, udp_msg->topic_name, 50);

					if (udp_msg->type == 0) {
						// este int
						long long int_number = ntohl(*(uint32_t*)(udp_msg->data + 1));
						if (udp_msg->data[0]) {
							int_number *= -1;
						}

						sprintf(tcp_msg.data, "%lld", int_number);
            			strcpy(&tcp_msg.type, "INT");

					} else if (udp_msg->type == 1) {
						// este short real
						double real_number = ntohs(*(uint16_t*)(udp_msg->data));
						real_number /= 100;
						sprintf(tcp_msg.data, "%.2f", real_number);
            			strcpy(&tcp_msg.type, "SHORT_REAL");

					} else if (udp_msg->type == 2) {
						// este float
						double real_number =  ntohl(*(uint32_t*)(udp_msg->data + 1));
						real_number /= pow(10, udp_msg->data[5]);
						if (udp_msg->data[0]) {
		                	real_number *= -1;
		            	}

			            sprintf(tcp_msg.data, "%lf", real_number);
			            strcpy(&tcp_msg.type, "FLOAT");

					} else {
						// este string
						strcpy(tcp_msg.data, "STRING");
            			strcpy(&tcp_msg.type, udp_msg->data);
					}

					for (int j = 0; j < curent_sub; j++) {
						if (strcmp(&list_subscribers[j].topic, tcp_msg.topic_name) == 0) {
							n = send(list_subscribers[j].socket, (char*) &tcp_msg, sizeof(struct tcp_msg_t), 0);
							DIE(n < 0, "sendERR");
						}
					}

				} else if (i == tcp_sockfd) {
					// a venit o cerere de conexiune pe socketul inactiv (cel cu listen),
					// pe care serverul o accepta
					tcp_socklen = sizeof(new_tcp);
					newsockfd = accept(tcp_sockfd, (struct sockaddr *) &new_tcp, &tcp_socklen);
					DIE(newsockfd < 0, "accept");

					// se adauga noul socket intors de accept() la multimea descriptorilor de citire
					FD_SET(newsockfd, &read_fds);
					if (newsockfd > fdmax) { 
						fdmax = newsockfd;
					}
					n = recv(newsockfd, buffer, BUFLEN - 1, 0);
					DIE(n < 0, "recv_id");
					strcpy(&clients_id[i], buffer);

					printf("New client %s connected from %s:%d \n", buffer, 
						inet_ntoa(new_tcp.sin_addr), ntohs(new_tcp.sin_port));

				} else {
					// s-au primit date pe unul din socketii de client,
					// asa ca serverul trebuie sa le receptioneze
					memset(buffer, 0, BUFLEN);
					n = recv(i, buffer, sizeof(buffer), 0);
					DIE(n < 0, "recv");

					if (n == 0) {
						// conexiunea s-a inchis
						printf("Client %s disconnected \n", &clients_id[i - 1]);
						close(i);

						// se scoate din multimea de citire socketul inchis 
						FD_CLR(i, &read_fds);
					} else {
						// subscribe & unsubscribe
						char* p = strtok(buffer, " ");
						if (strcmp(p, "subscribe") == 0) {
							p = strtok(NULL, " ");
							list_subscribers[curent_sub].socket = i;
							strcpy(&list_subscribers[curent_sub].topic , p);
							strcpy(&list_subscribers[curent_sub].id, &clients_id[i]);
							p = strtok(NULL, " ");
							list_subscribers[curent_sub].sf = atoi(p);
							curent_sub++;
						} else if (strcmp(p, "unsubscribe") == 0) {
							p = strtok(NULL, "\n");
							for (int j = 0; j < curent_sub; j++) {
								if (strcmp(&list_subscribers[j].topic, p) == 0 &&
								 strcmp(&list_subscribers[j].id, &clients_id[i]) == 0) {
									for (int k = j; k <= curent_sub; k++) {
										list_subscribers[k] = list_subscribers[k + 1];
									}
									curent_sub--;
									break;
								}
							}
						}
					}
				}
			}
		}
	}

	close_all_clients(&read_fds, fdmax);

	return 0;
}
